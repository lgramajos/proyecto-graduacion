<?php
session_start();
$c = $_GET['c'] ?? 'auth';
$a = $_GET['a'] ?? 'login';

$controllerFile = __DIR__ . "/app/controllers/" . ucfirst($c) . "Controller.php";
if (!file_exists($controllerFile)) { http_response_code(404); exit("Controlador no encontrado"); }
require_once $controllerFile;

$controllerClass = ucfirst($c) . "Controller";
$controller = new $controllerClass();

if (!method_exists($controller, $a)) { http_response_code(404); exit("Acción no encontrada"); }
$controller->$a();

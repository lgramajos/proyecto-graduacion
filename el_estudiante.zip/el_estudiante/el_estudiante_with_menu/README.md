# El Estudiante - Login MVC (CSS separado)
Estructura MVC mínima con login y CSS externo.

## Estructura
- index.php (front controller)
- app/config/db.php
- app/models/Usuario.php
- app/controllers/AuthController.php
- app/views/auth/login.php
- public/assets/css/style.css
- database/schema.sql

## Uso
1) Copia la carpeta `el_estudiante` a `C:\xampp\htdocs\`
2) Importa `database/schema.sql` en phpMyAdmin
3) Abre: http://localhost/el_estudiante/?c=auth&a=login
4) Usuario demo: **admin** / **123456**

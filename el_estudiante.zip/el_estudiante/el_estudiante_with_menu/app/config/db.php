<?php
class DB {
  private static $c = null;
  public static function conn(){
    if (self::$c === null) {
      $dsn = "mysql:host=127.0.0.1:3308;dbname=el_estudiante;charset=utf8mb4";
      self::$c = new PDO($dsn, "root", "", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
      ]);
    }
    return self::$c;
  }
}

<?php
require_once __DIR__ . '/../models/Usuario.php';
require_once __DIR__ . '/../config/db.php';

class AuthController {
  // Las vistas de auth se renderizan sin layout (como ya lo tienes)
  private function view($view, $vars = []){
    extract($vars);
    include __DIR__ . '/../views/auth/' . $view . '.php';
  }

  public function login(){
    $msg = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      $usuario = $_POST['usuario']  ?? '';
      $clave   = $_POST['password'] ?? '';

      // Busca por usuario (o ajusta a tu método si también usas email)
      $u = Usuario::findByUsuario($usuario);

      if ($u) {
        // ⚠️ Si luego usas password_hash, cambia esta línea por:
        // $ok = password_verify($clave, $u['password']);
        $ok = ($u['password'] === $clave);

        if ($ok && (int)($u['estado'] ?? 1) === 1) {
          // Guarda datos en sesión, incluyendo el rol
          $_SESSION['user'] = [
            'id'      => $u['id_usuario'],
            'usuario' => $u['usuario'],
            'nombre'  => $u['nombre'],
            'email'   => $u['email'] ?? null,
            'rol'     => $u['rol']   ?? 'usuario', // << importante
          ];
          header('Location: ?c=home&a=index');
          exit;
        }
      }
      $msg = "❌ Usuario o contraseña incorrectos.";
    }

    $this->view('login', compact('msg'));
  }

  public function register(){
    $msg = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      $usuario = trim($_POST['usuario']  ?? '');
      $nombre  = trim($_POST['nombre']   ?? '');
      $email   = trim($_POST['email']    ?? '');
      $pass    = trim($_POST['password'] ?? '');

      if ($usuario === '' || $nombre === '' || $pass === '') {
        $msg = '⚠️ Completa los campos obligatorios.';
      } else {
        try {
          $pdo = DB::conn();

          // Evitar duplicados por usuario o email
          $emailVal = ($email === '') ? null : $email;
          $check = $pdo->prepare("SELECT 1 FROM usuarios WHERE usuario=? OR email <=> ? LIMIT 1");
          $check->execute([$usuario, $emailVal]);

          if ($check->fetch()) {
            $msg = '⚠️ Ese usuario o correo ya existe.';
          } else {
            // Rol por defecto para nuevos usuarios (ajústalo si quieres otro)
            $rol = 'ventas';

            // ⚠️ Si usas password_hash: $hash = password_hash($pass, PASSWORD_BCRYPT)
            $ins = $pdo->prepare("
              INSERT INTO usuarios (usuario, nombre, email, rol, estado, password)
              VALUES (?,?,?,?,1,?)
            ");
            $ins->execute([$usuario, $nombre, $emailVal, $rol, $pass]);
            header('Location: ?c=auth&a=login');
            exit;
          }
        } catch (Exception $e) {
          $msg = 'Error al registrar: ' . $e->getMessage();
        }
      }
    }

    $this->view('register', compact('msg'));
  }

  public function logout(){
    session_destroy();
    header("Location: ?c=auth&a=login");
    exit;
  }
}

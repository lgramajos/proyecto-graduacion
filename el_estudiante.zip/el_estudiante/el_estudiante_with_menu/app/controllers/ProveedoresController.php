<?php
require_once __DIR__ . '/../models/Proveedor.php';

class ProveedoresController {
  private function view($path, $vars = []){
    extract($vars);
    include __DIR__ . '/../views/layout/header.php';
    include __DIR__ . '/../views/' . $path . '.php';
    include __DIR__ . '/../views/layout/footer.php';
  }
  public function login(){ $this->index(); }
  public function index(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} $proveedores=Proveedor::all(); $this->view('proveedores/index', compact('proveedores')); }
  public function crear(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} $proveedor=null; $this->view('proveedores/form', compact('proveedor')); }
  public function guardar(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} Proveedor::insert($_POST); header('Location: ?c=proveedores&a=index'); }
  public function editar(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} $id=$_GET['id']??null; if(!$id){http_response_code(400);exit('ID requerido');} $proveedor=Proveedor::find($id); if(!$proveedor){http_response_code(404);exit('Proveedor no encontrado');} $this->view('proveedores/form', compact('proveedor')); }
  public function actualizar(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} $id=$_POST['id']??null; if(!$id){http_response_code(400);exit('ID requerido');} Proveedor::update($id,$_POST); header('Location: ?c=proveedores&a=index'); }
  public function eliminar(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} $id=$_GET['id']??null; if(!$id){http_response_code(400);exit('ID requerido');} Proveedor::delete($id); header('Location: ?c=proveedores&a=index'); }
}

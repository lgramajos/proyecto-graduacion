<?php
require_once __DIR__ . '/../models/Cliente.php';

class ClientesController {
  private function view($path, $vars = []){
    extract($vars);
    include __DIR__ . '/../views/layout/header.php';
    include __DIR__ . '/../views/' . $path . '.php';
    include __DIR__ . '/../views/layout/footer.php';
  }
  public function login(){ $this->index(); }
  public function index(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} $clientes=Cliente::all(); $this->view('clientes/index', compact('clientes')); }
  public function crear(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} $cliente=null; $this->view('clientes/form', compact('cliente')); }
  public function guardar(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} Cliente::insert($_POST); header('Location: ?c=clientes&a=index'); }
  public function editar(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} $id=$_GET['id']??null; if(!$id){http_response_code(400);exit('ID requerido');} $cliente=Cliente::find($id); if(!$cliente){http_response_code(404);exit('Cliente no encontrado');} $this->view('clientes/form', compact('cliente')); }
  public function actualizar(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} $id=$_POST['id']??null; if(!$id){http_response_code(400);exit('ID requerido');} Cliente::update($id,$_POST); header('Location: ?c=clientes&a=index'); }
  public function eliminar(){ if(!isset($_SESSION['user'])){header('Location: ?c=auth&a=login');exit;} $id=$_GET['id']??null; if(!$id){http_response_code(400);exit('ID requerido');} Cliente::delete($id); header('Location: ?c=clientes&a=index'); }
}

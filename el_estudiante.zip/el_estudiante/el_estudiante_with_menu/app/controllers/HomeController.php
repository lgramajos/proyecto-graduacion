<?php
class HomeController {
  // Renderiza una vista dentro del layout general
  private function view($path, $vars = []){
    extract($vars);
    include __DIR__ . '/../views/layout/header.php';
    include __DIR__ . '/../views/' . $path . '.php';
    include __DIR__ . '/../views/layout/footer.php';
  }

  // Asegura que el usuario haya iniciado sesi�n
  private function requireLogin(){
    if (!isset($_SESSION['user'])) {
      header('Location: ?c=auth&a=login');
      exit;
    }
  }

  // P�gina principal (Dashboard / Men�)
  public function index(){
    $this->requireLogin();
    // Puedes pasar datos a la vista si lo necesitas
    $user = $_SESSION['user'];
    $this->view('home/index', compact('user'));
  }
}

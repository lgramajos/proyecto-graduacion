<?php
// app/controllers/ProductosController.php
require_once __DIR__ . '/../models/Producto.php';
require_once __DIR__ . '/../models/Proveedor.php';

class ProductosController {
  private function view($path, $vars = []){
    extract($vars);
    include __DIR__ . '/../views/layout/header.php';
    include __DIR__ . '/../views/' . $path . '.php';
    include __DIR__ . '/../views/layout/footer.php';
  }

  public function login(){ $this->index(); }

  public function index(){
    if (!isset($_SESSION['user'])) { header('Location: ?c=auth&a=login'); exit; }
    $productos = Producto::all();
    $this->view('productos/index', compact('productos'));
  }

  public function crear(){
    if (!isset($_SESSION['user'])) { header('Location: ?c=auth&a=login'); exit; }
    $producto = null;
    $proveedores = Proveedor::all(); // para el select
    $this->view('productos/form', compact('producto', 'proveedores'));
  }

  public function guardar(){
    if (!isset($_SESSION['user'])) { header('Location: ?c=auth&a=login'); exit; }
    Producto::insert($_POST);
    header('Location: ?c=productos&a=index');
  }

  public function editar(){
    if (!isset($_SESSION['user'])) { header('Location: ?c=auth&a=login'); exit; }
    $id = $_GET['id'] ?? null;
    if (!$id) { http_response_code(400); exit('ID requerido'); }
    $producto = Producto::find($id);
    if (!$producto) { http_response_code(404); exit('Producto no encontrado'); }
    $proveedores = Proveedor::all();
    $this->view('productos/form', compact('producto','proveedores'));
  }

  public function actualizar(){
    if (!isset($_SESSION['user'])) { header('Location: ?c=auth&a=login'); exit; }
    $id = $_POST['id'] ?? null;
    if (!$id) { http_response_code(400); exit('ID requerido'); }
    Producto::update($id, $_POST);
    header('Location: ?c=productos&a=index');
  }

  public function eliminar(){
    if (!isset($_SESSION['user'])) { header('Location: ?c=auth&a=login'); exit; }
    $id = $_GET['id'] ?? null;
    if (!$id) { http_response_code(400); exit('ID requerido'); }
    Producto::delete($id);
    header('Location: ?c=productos&a=index');
  }
}

<?php
require_once __DIR__ . '/../config/db.php';
class Usuario {
  public static function findByUsuario($usuario){
    $s = DB::conn()->prepare("SELECT * FROM usuarios WHERE usuario=? AND estado=1 LIMIT 1");
    $s->execute([$usuario]);
    return $s->fetch();
  }
}

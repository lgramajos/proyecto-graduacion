<?php
// app/models/Producto.php
require_once __DIR__ . '/../config/db.php';

class Producto {
  public static function all(){
    $pdo = DB::conn();
    // Traemos proveedor (razon_social) para mostrarlo en el listado
    $sql = "SELECT p.*, pr.razon_social AS proveedor_nombre
            FROM productos p
            JOIN proveedores pr ON pr.id = p.id_proveedor
            ORDER BY p.id DESC";
    return $pdo->query($sql)->fetchAll();
  }

  public static function find($id){
    $pdo = DB::conn();
    $st = $pdo->prepare("SELECT * FROM productos WHERE id = ?");
    $st->execute([$id]);
    return $st->fetch();
  }

  public static function insert($data){
    $pdo = DB::conn();
    $sql = "INSERT INTO productos (nombre, precio, stock, id_proveedor, suministros)
            VALUES (?,?,?,?,?)";
    $st = $pdo->prepare($sql);
    $st->execute([
      $data['nombre'] ?? '',
      $data['precio'] ?? 0,
      $data['stock'] ?? 0,
      $data['id_proveedor'] ?? null,
      $data['suministros'] ?? ''
    ]);
  }

  public static function update($id, $data){
    $pdo = DB::conn();
    $sql = "UPDATE productos
            SET nombre=?, precio=?, stock=?, id_proveedor=?, suministros=?
            WHERE id=?";
    $st = $pdo->prepare($sql);
    $st->execute([
      $data['nombre'] ?? '',
      $data['precio'] ?? 0,
      $data['stock'] ?? 0,
      $data['id_proveedor'] ?? null,
      $data['suministros'] ?? '',
      $id
    ]);
  }

  public static function delete($id){
    $pdo = DB::conn();
    $st = $pdo->prepare("DELETE FROM productos WHERE id = ?");
    $st->execute([$id]);
  }
}

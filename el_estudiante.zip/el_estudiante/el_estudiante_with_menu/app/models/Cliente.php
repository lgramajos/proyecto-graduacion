<?php
// app/models/Cliente.php
require_once __DIR__ . '/../config/db.php';

class Cliente {
  public static function all(){
    $pdo = DB::conn();
    $st = $pdo->query("SELECT * FROM clientes ORDER BY id DESC");
    return $st->fetchAll();
  }

  public static function find($id){
    $pdo = DB::conn();
    $st = $pdo->prepare("SELECT * FROM clientes WHERE id = ?");
    $st->execute([$id]);
    return $st->fetch();
  }

  public static function insert($data){
    $pdo = DB::conn();
    // Cambiamos descripcion -> frecuencia_compra
    $sql = "INSERT INTO clientes (nombre, correo, telefono, frecuencia_compra) VALUES (?,?,?,?)";
    $st = $pdo->prepare($sql);
    $st->execute([
      $data['nombre'] ?? '',
      $data['correo'] ?? null,
      $data['telefono'] ?? null,
      $data['frecuencia_compra'] ?? null
    ]);
  }

  public static function update($id, $data){
    $pdo = DB::conn();
    // Cambiamos descripcion -> frecuencia_compra
    $sql = "UPDATE clientes SET nombre=?, correo=?, telefono=?, frecuencia_compra=? WHERE id=?";
    $st = $pdo->prepare($sql);
    $st->execute([
      $data['nombre'] ?? '',
      $data['correo'] ?? null,
      $data['telefono'] ?? null,
      $data['frecuencia_compra'] ?? null,
      $id
    ]);
  }

  public static function delete($id){
    $pdo = DB::conn();
    $st = $pdo->prepare("DELETE FROM clientes WHERE id = ?");
    $st->execute([$id]);
  }
}


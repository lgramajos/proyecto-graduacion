<?php
require_once __DIR__ . '/../config/db.php';

class Proveedor {
  public static function all(){
    $pdo = DB::conn();
    $st = $pdo->query("SELECT * FROM proveedores ORDER BY id DESC");
    return $st->fetchAll();
  }

  public static function find($id){
    $pdo = DB::conn();
    $st = $pdo->prepare("SELECT * FROM proveedores WHERE id = ?");
    $st->execute([$id]);
    return $st->fetch();
  }

  public static function insert($data){
    $pdo = DB::conn();
    $sql = "INSERT INTO proveedores (razon_social, nit, correo, telefono, suministros) VALUES (?,?,?,?,?)";
    $st = $pdo->prepare($sql);
    $st->execute([
      $data['razon_social'] ?? '',
      $data['nit'] ?? null,
      $data['correo'] ?? null,
      $data['telefono'] ?? null,
      $data['suministros'] ?? null
    ]);
  }

  public static function update($id, $data){
    $pdo = DB::conn();
    $sql = "UPDATE proveedores SET razon_social=?, nit=?, correo=?, telefono=?, suministros=? WHERE id=?";
    $st = $pdo->prepare($sql);
    $st->execute([
      $data['razon_social'] ?? '',
      $data['nit'] ?? null,
      $data['correo'] ?? null,
      $data['telefono'] ?? null,
      $data['suministros'] ?? null,
      $id
    ]);
  }

  public static function delete($id){
    $pdo = DB::conn();
    $st = $pdo->prepare("DELETE FROM proveedores WHERE id = ?");
    $st->execute([$id]);
  }
}

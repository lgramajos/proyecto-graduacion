<?php
$rol = $_SESSION['user']['rol'] ?? 'usuario';
?>

<?php if ($rol === 'admin'): ?>
<section class="grid-menu centered">
  <a class="tile tile-orange" href="?c=productos">
    <div class="tile-icon">📦</div>
    <div class="tile-title">Inventario</div>
  </a>

  <a class="tile tile-blue" href="?c=pedidos">
    <div class="tile-icon">📝</div>
    <div class="tile-title">Pedidos</div>
  </a>

  <a class="tile tile-red" href="?c=clientes">
    <div class="tile-icon">👥</div>
    <div class="tile-title">Clientes</div>
  </a>

  <a class="tile tile-green" href="?c=proveedores">
    <div class="tile-icon">🛍️</div>
    <div class="tile-title">Proveedores</div>
  </a>
</section>
<?php else: ?>
<section class="grid-menu centered">
  <a class="tile tile-blue" href="?c=pedidos">
    <div class="tile-icon">🛒</div>
    <div class="tile-title">Mis pedidos</div>
  </a>

  <a class="tile tile-orange" href="?c=productos">
    <div class="tile-icon">📚</div>
    <div class="tile-title">Catálogo</div>
  </a>
</section>
<?php endif; ?>

<?php /* app/views/productos/form.php */ ?>
<div class="card" style="background:#fff;border-radius:22px;box-shadow:0 8px 28px rgba(0,0,0,.12);padding:22px;max-width:800px;margin:0 auto">
  <h2 style="margin-top:0"><?= $producto ? 'Editar' : 'Agregar' ?> producto</h2>

  <form method="post" action="?c=productos&a=<?= $producto ? 'actualizar' : 'guardar' ?>">
    <?php if ($producto): ?>
      <input type="hidden" name="id" value="<?= htmlspecialchars($producto['id']) ?>">
    <?php endif; ?>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
      <div>
        <label>Nombre *</label>
        <input name="nombre" required value="<?= htmlspecialchars($producto['nombre'] ?? '') ?>" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
      </div>

      <div>
        <label>Precio *</label>
        <input type="number" step="0.01" name="precio" required value="<?= htmlspecialchars($producto['precio'] ?? '0.00') ?>" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
      </div>

      <div>
        <label>Stock *</label>
        <input type="number" name="stock" required value="<?= htmlspecialchars($producto['stock'] ?? '0') ?>" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
      </div>

      <div>
        <label>Proveedor *</label>
        <select name="id_proveedor" required style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
          <option value="">-- Selecciona proveedor --</option>
          <?php foreach ($proveedores as $prov):
            $sel = (string)($producto['id_proveedor'] ?? '') === (string)$prov['id'] ? 'selected' : '';
          ?>
            <option value="<?= htmlspecialchars($prov['id']) ?>" <?= $sel ?>>
              <?= htmlspecialchars($prov['razon_social'] ?? ($prov['nombre'] ?? 'Proveedor #'.$prov['id'])) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div style="grid-column:1/-1">
        <label>Suministros (clasificación) *</label>
        <select name="suministros" required style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
          <?php
            $options = [
              "Material didáctico",
              "Papelería escolar",
              "Libros y publicaciones",
              "Mobiliario e higiene",
              "Decoración y eventos",
              "Tecnología educativa"
            ];
            $val = $producto['suministros'] ?? '';
            foreach ($options as $opt):
              $sel = ($val === $opt) ? "selected" : "";
              echo "<option value='$opt' $sel>$opt</option>";
            endforeach;
          ?>
        </select>
      </div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px">
      <button type="submit" class="btn" style="background:#6366f1;color:#fff;border:0;border-radius:14px;padding:10px 16px;font-weight:700;cursor:pointer">
        <?= $producto ? 'Actualizar' : 'Guardar' ?>
      </button>
      <a class="btn" style="background:#F29F05;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=productos&a=index">Cancelar</a>
      <?php if ($producto): ?>
        <a class="btn" style="background:#EA4335;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=productos&a=eliminar&id=<?= urlencode($producto['id']) ?>" onclick="return confirm('¿Eliminar producto #<?= (int)$producto['id'] ?>?')">Eliminar</a>
      <?php endif; ?>
    </div>
  </form>
</div>

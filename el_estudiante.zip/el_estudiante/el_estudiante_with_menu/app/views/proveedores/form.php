<?php /* app/views/proveedores/form.php */ ?>
<div class="card" style="background:#fff;border-radius:22px;box-shadow:0 8px 28px rgba(0,0,0,.12);padding:22px;max-width:800px;margin:0 auto">
  <h2 style="margin-top:0"><?= $proveedor ? 'Editar' : 'Agregar' ?> proveedor</h2>
  <form method="post" action="?c=proveedores&a=<?= $proveedor ? 'actualizar' : 'guardar' ?>">
    <?php if ($proveedor): ?>
      <input type="hidden" name="id" value="<?= htmlspecialchars($proveedor['id']) ?>">
    <?php endif; ?>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
      <div>
        <label>Razón social *</label>
        <input name="razon_social" required value="<?= htmlspecialchars($proveedor['razon_social'] ?? '') ?>" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
      </div>
      <div>
        <label>NIT</label>
        <input name="nit" value="<?= htmlspecialchars($proveedor['nit'] ?? '') ?>" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
      </div>
      <div>
        <label>Correo</label>
        <input type="email" name="correo" value="<?= htmlspecialchars($proveedor['correo'] ?? '') ?>" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
      </div>
      <div>
        <label>Teléfono</label>
        <input name="telefono" value="<?= htmlspecialchars($proveedor['telefono'] ?? '') ?>" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
      </div>
      <div style="grid-column:1/-1">
        <label>Suministros</label>
        <select name="suministros" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
          <?php
            $options = [
              "Material didáctico",
              "Papelería escolar",
              "Libros y publicaciones",
              "Mobiliario e higiene",
              "Decoración y eventos",
              "Tecnología educativa"
            ];
            $val = $proveedor['suministros'] ?? '';
            foreach ($options as $opt):
              $sel = ($val === $opt) ? "selected" : "";
              echo "<option value='$opt' $sel>$opt</option>";
            endforeach;
          ?>
        </select>
      </div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px">
      <button type="submit" class="btn" style="background:#10b981;color:#fff;border:0;border-radius:14px;padding:10px 16px;font-weight:700;cursor:pointer"><?= $proveedor ? 'Actualizar' : 'Guardar' ?></button>
      <a class="btn" style="background:#F29F05;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=proveedores&a=index">Cancelar</a>
      <?php if ($proveedor): ?>
        <a class="btn" style="background:#EA4335;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=proveedores&a=eliminar&id=<?= urlencode($proveedor['id']) ?>" onclick="return confirm('¿Eliminar proveedor #<?= (int)$proveedor['id'] ?>?')">Eliminar</a>
      <?php endif; ?>
    </div>
  </form>
</div>

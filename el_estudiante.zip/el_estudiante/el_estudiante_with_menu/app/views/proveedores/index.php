<?php /* app/views/proveedores/index.php */ ?>
<div class="toolbar" style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px">
  <a class="btn" style="background:#10b981;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=proveedores&a=index">Proveedores</a>
  <a class="btn" style="background:#1689F2;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=proveedores&a=crear">Agregar proveedor</a>
  <a class="btn" style="background:#F29F05;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=home&a=index">Menú</a>
</div>

<div class="card" style="background:#fff;border-radius:22px;box-shadow:0 8px 28px rgba(0,0,0,.12);padding:18px">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
    <h2 style="margin:0">Listado de Proveedores</h2>
    <span class="pill" style="display:inline-block;padding:6px 10px;border-radius:999px;background:#f1f5f9;font-size:12px">
      <?= count($proveedores) ?> registros
    </span>
  </div>

  <div style="overflow:auto">
    <table style="width:100%;border-collapse:separate;border-spacing:0 10px">
      <thead>
        <tr>
          <th style="text-align:left;padding:8px 12px;color:#666">ID</th>
          <th style="text-align:left;padding:8px 12px;color:#666">Razón social</th>
          <th style="text-align:left;padding:8px 12px;color:#666">NIT</th>
          <th style="text-align:left;padding:8px 12px;color:#666">Correo</th>
          <th style="text-align:left;padding:8px 12px;color:#666">Teléfono</th>
          <th style="text-align:left;padding:8px 12px;color:#666">Suministros</th>
          <th style="text-align:left;padding:8px 12px;color:#666">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$proveedores): ?>
          <tr>
            <td colspan="7" style="padding:18px;background:#fff;text-align:center">
              No hay proveedores aún.
            </td>
          </tr>
        <?php else: foreach ($proveedores as $p): ?>
          <tr style="background:#fff;box-shadow:0 8px 28px rgba(0,0,0,.08)">
            <td style="padding:12px 12px"><?= htmlspecialchars($p['id']) ?></td>
            <td style="padding:12px 12px"><?= htmlspecialchars($p['razon_social']) ?></td>
            <td style="padding:12px 12px"><?= htmlspecialchars($p['nit']) ?></td>
            <td style="padding:12px 12px"><?= htmlspecialchars($p['correo']) ?></td>
            <td style="padding:12px 12px"><?= htmlspecialchars($p['telefono']) ?></td>
            <td style="padding:12px 12px"><?= htmlspecialchars($p['suministros']) ?></td>
            <td style="padding:12px 12px">
              <a class="btn" style="background:#1689F2;color:#fff;border-radius:14px;padding:8px 12px;font-weight:700;text-decoration:none" 
                 href="?c=proveedores&a=editar&id=<?= urlencode($p['id']) ?>">Editar</a>
              <a class="btn" style="background:#EA4335;color:#fff;border-radius:14px;padding:8px 12px;font-weight:700;text-decoration:none" 
                 href="?c=proveedores&a=eliminar&id=<?= urlencode($p['id']) ?>" 
                 onclick="return confirm('¿Eliminar proveedor #<?= (int)$p['id'] ?>?')">Eliminar</a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

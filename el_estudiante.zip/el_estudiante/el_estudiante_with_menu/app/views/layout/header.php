<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sistema de Gestión</title>
  <?php
    // BASE URL dinámico según la carpeta actual
    $BASE = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
  ?>
  <link rel="stylesheet" href="<?= $BASE ?>/public/assets/css/style.css">
</head>
<body class="app">
<header class="topbar">
  <div class="brand">Sistema de Gestión de Inventarios y Pedidos</div>
  <div class="user-area">
    <span class="user-name"><?= htmlspecialchars($_SESSION['user']['nombre'] ?? 'Usuario') ?></span>
    <a class="logout" href="?c=auth&a=logout" title="Salir">⎋</a>
  </div>
</header>
<main class="container">

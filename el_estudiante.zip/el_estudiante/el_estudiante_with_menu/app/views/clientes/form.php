<?php /* app/views/clientes/form.php */ ?>
<div class="card" style="background:#fff;border-radius:22px;box-shadow:0 8px 28px rgba(0,0,0,.12);padding:22px;max-width:800px;margin:0 auto">
  <h2 style="margin-top:0"><?= $cliente ? 'Editar' : 'Agregar' ?> cliente</h2>

  <form method="post" action="?c=clientes&a=<?= $cliente ? 'actualizar' : 'guardar' ?>">
    <?php if ($cliente): ?>
      <input type="hidden" name="id" value="<?= htmlspecialchars($cliente['id']) ?>">
    <?php endif; ?>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
      <div>
        <label>Nombre *</label>
        <input name="nombre" required value="<?= htmlspecialchars($cliente['nombre'] ?? '') ?>" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
      </div>

      <div>
        <label>Correo</label>
        <input type="email" name="correo" value="<?= htmlspecialchars($cliente['correo'] ?? '') ?>" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
      </div>

      <div>
        <label>Teléfono</label>
        <input name="telefono" value="<?= htmlspecialchars($cliente['telefono'] ?? '') ?>" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
      </div>

      <div style="grid-column:1/-1">
        <label>Frecuencia de compra</label>
        <select name="frecuencia_compra" style="width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:12px">
          <?php
            $opts = ["Alta","Media","Baja"];
            $val = $cliente['frecuencia_compra'] ?? '';
            foreach ($opts as $opt):
              $sel = ($val === $opt) ? "selected" : "";
              echo "<option value='$opt' $sel>$opt</option>";
            endforeach;
          ?>
        </select>
      </div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px">
      <button type="submit" class="btn" style="background:#ef4444;color:#fff;border:0;border-radius:14px;padding:10px 16px;font-weight:700;cursor:pointer">
        <?= $cliente ? 'Actualizar' : 'Guardar' ?>
      </button>
      <a class="btn" style="background:#F29F05;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=clientes&a=index">Cancelar</a>
      <?php if ($cliente): ?>
        <a class="btn" style="background:#EA4335;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=clientes&a=eliminar&id=<?= urlencode($cliente['id']) ?>" onclick="return confirm('¿Eliminar cliente #<?= (int)$cliente['id'] ?>?')">Eliminar</a>
      <?php endif; ?>
    </div>
  </form>
</div>

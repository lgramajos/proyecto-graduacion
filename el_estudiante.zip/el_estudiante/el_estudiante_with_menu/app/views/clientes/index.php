<?php /* app/views/clientes/index.php */ ?>
<div class="toolbar" style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px">
  <a class="btn" style="background:#ef4444;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=clientes&a=index">Clientes</a>
  <a class="btn" style="background:#1689F2;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=clientes&a=crear">Agregar cliente</a>
  <a class="btn" style="background:#F29F05;color:#fff;border-radius:14px;padding:10px 16px;font-weight:700;text-decoration:none" href="?c=home&a=index">Menú</a>
</div>

<div class="card" style="background:#fff;border-radius:22px;box-shadow:0 8px 28px rgba(0,0,0,.12);padding:18px">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
    <h2 style="margin:0">Listado de Clientes</h2>
    <span class="pill" style="display:inline-block;padding:6px 10px;border-radius:999px;background:#f1f5f9;font-size:12px"><?= count($clientes) ?> registros</span>
  </div>

  <div style="overflow:auto">
    <table style="width:100%;border-collapse:separate;border-spacing:0 10px">
      <thead>
        <tr>
          <th style="text-align:left;padding:8px 12px;color:#666">ID</th>
          <th style="text-align:left;padding:8px 12px;color:#666">Nombre</th>
          <th style="text-align:left;padding:8px 12px;color:#666">Correo</th>
          <th style="text-align:left;padding:8px 12px;color:#666">Teléfono</th>
          <th style="text-align:left;padding:8px 12px;color:#666">Frecuencia compra</th>
          <th style="text-align:left;padding:8px 12px;color:#666">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$clientes): ?>
          <tr><td colspan="6" style="padding:18px;background:#fff;text-align:center">No hay clientes aún.</td></tr>
        <?php else: foreach ($clientes as $p): ?>
          <tr style="background:#fff;box-shadow:0 8px 28px rgba(0,0,0,.08)">
            <td style="padding:12px 12px"><?= htmlspecialchars($p['id']) ?></td>
            <td style="padding:12px 12px"><?= htmlspecialchars($p['nombre']) ?></td>
            <td style="padding:12px 12px"><?= htmlspecialchars($p['correo']) ?></td>
            <td style="padding:12px 12px"><?= htmlspecialchars($p['telefono']) ?></td>
            <td style="padding:12px 12px"><?= htmlspecialchars($p['frecuencia_compra']) ?></td>
            <td style="padding:12px 12px">
              <a class="btn" style="background:#1689F2;color:#fff;border-radius:14px;padding:8px 12px;font-weight:700;text-decoration:none" href="?c=clientes&a=editar&id=<?= urlencode($p['id']) ?>">Editar</a>
              <a class="btn" style="background:#EA4335;color:#fff;border-radius:14px;padding:8px 12px;font-weight:700;text-decoration:none" href="?c=clientes&a=eliminar&id=<?= urlencode($p['id']) ?>" onclick="return confirm('¿Eliminar cliente #<?= (int)$p['id'] ?>?')">Eliminar</a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

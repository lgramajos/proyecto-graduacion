<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <style>
    /* Fondo dividido: izquierda azul, derecha amarillo */
    body.auth {
      margin: 0;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background: linear-gradient(to right, #1d9bf0 50%, #f59e0b 50%);
      font-family: 'Poppins', 'Segoe UI', Roboto, Arial, sans-serif;
    }

    /* Tarjeta */
    .login-card {
      background: #ffffff;
      padding: 40px 30px;
      border-radius: 18px;
      box-shadow: 0 10px 28px rgba(0,0,0,0.25);
      width: min(380px, 90vw);
      text-align: center;
      animation: fadeIn 0.6s ease;
    }

    /* Título */
    .login-card h1 {
      margin: 0 0 20px;
      font-size: 28px;
      font-weight: 800;
      color: #1d9bf0; /* azul vivo */
    }

    /* Formularios */
    .login-card form {
      text-align: center;
    }

    .login-card label {
      display: block;
      margin: 14px auto 6px;
      font-size: 15px;
      font-weight: 600;
      color: #374151;
      max-width: 260px;
      text-align: left;
    }

    .login-card input {
      display: block;
      margin: 0 auto;
      width: 100%;
      max-width: 260px;
      padding: 10px;
      font-size: 15px;
      border: 2px solid #e5e7eb;
      border-radius: 10px;
      outline: none;
      transition: 0.25s;
      background: #f9fafb;
    }

    .login-card input:focus {
      border-color: #1d9bf0;
      box-shadow: 0 0 6px #93c5fd;
      background: #fff;
    }

    /* Botón */
    .login-card .btn {
      margin-top: 20px;
      width: 100%;
      max-width: 260px;
      padding: 12px;
      border: none;
      border-radius: 10px;
      background: linear-gradient(90deg, #1d9bf0, #f59e0b);
      color: #fff;
      font-size: 15px;
      font-weight: bold;
      cursor: pointer;
      transition: transform 0.15s ease, box-shadow 0.15s ease;
    }

    .login-card .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 18px rgba(245,158,11,0.45);
    }

    /* Mensaje */
    .msg {
      margin-top: 18px;
      padding: 10px;
      border-radius: 8px;
      background: #fee2e2;
      border: 1px solid #fecaca;
      color: #b91c1c;
      font-size: 14px;
      text-align: center;
      max-width: 260px;
      margin-left: auto;
      margin-right: auto;
    }

    /* Animación entrada */
    @keyframes fadeIn {
      from {opacity: 0; transform: translateY(10px);}
      to {opacity: 1; transform: translateY(0);}
    }
  </style>
</head>
<body class="auth">
  <div class="login-card">
    <h1>Iniciar sesión</h1>
    <form method="post">
      <label>Usuario
        <input name="usuario" required>
      </label>
      <label>Contraseña
        <input type="password" name="password" required>
      </label>
      <button class="btn" type="submit">Entrar</button>
    </form>
    <p class="tiny" style="text-align:center;margin-top:12px;">¿No tienes cuenta? <a href="?c=auth&a=register" class="link" style="color:#1d9bf0;font-weight:700;text-decoration:none;">Crear cuenta</a></p>
    <?php if (!empty($msg)): ?>
      <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>
  </div>
</body>
</html>

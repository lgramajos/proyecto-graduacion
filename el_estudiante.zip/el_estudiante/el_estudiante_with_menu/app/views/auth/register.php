<?php $BASE = rtrim(dirname($_SERVER['PHP_SELF']), '/\\'); ?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Crear cuenta</title>
  <link rel="stylesheet" href="<?= $BASE ?>/public/assets/css/style.css">
</head>
<body class="auth">
  <div class="login-card">
    <h1>Crear cuenta</h1>
    <form method="post">
      <label>Usuario *
        <input name="usuario" required>
      </label>
      <label>Nombre *
        <input name="nombre" required>
      </label>
      <label>Email
        <input type="email" name="email" placeholder="opcional">
      </label>
      <label>Contraseña *
        <input type="password" name="password" required>
      </label>
      <button class="btn" type="submit">Registrar</button>
    </form>
    <p class="tiny" style="text-align:center;margin-top:12px;">
      ¿Ya tienes cuenta? <a href="?c=auth&a=login" class="link" style="color:#1d9bf0;font-weight:700;text-decoration:none;">Inicia sesión</a>
    </p>
    <?php if (!empty($msg)): ?>
      <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>
  </div>
</body>
</html>

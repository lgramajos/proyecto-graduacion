CREATE DATABASE IF NOT EXISTS el_estudiante
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE el_estudiante;

CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  usuario    VARCHAR(50)  NOT NULL UNIQUE,
  nombre     VARCHAR(120) NOT NULL,
  email      VARCHAR(120) UNIQUE,
  rol        ENUM('admin','ventas','bodega') NOT NULL DEFAULT 'ventas',
  estado     TINYINT(1) NOT NULL DEFAULT 1,
  password   VARCHAR(255) NOT NULL,
  creado_en  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO usuarios (usuario, nombre, email, rol, estado, password)
VALUES ('admin','Administrador','admin@demo.com','admin',1,'123456')
ON DUPLICATE KEY UPDATE nombre=VALUES(nombre);


-- Proveedores con NIT
CREATE TABLE IF NOT EXISTS proveedores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  nit VARCHAR(30),
  correo VARCHAR(120),
  telefono VARCHAR(30),
  descripcion TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Clientes con NIT
CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  nit VARCHAR(30),
  correo VARCHAR(120),
  telefono VARCHAR(30),
  descripcion TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);


/* === MIGRACIÓN PUNTUAL: Proveedores descripción -> suministros (lista) ===
   Si tu tabla aún tiene 'descripcion', renómbrala a 'suministros' (VARCHAR).
*/
ALTER TABLE proveedores CHANGE COLUMN descripcion suministros VARCHAR(120);
